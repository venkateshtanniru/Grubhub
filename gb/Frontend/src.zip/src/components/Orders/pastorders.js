import React, { Component } from "react";
// import {Link} from "react-router-dom";

class Pastorders extends Component{
    render(){
        return(
            <div className="container-fluid">
                 
                 <h2>Past Orders!</h2>

            </div>
        )
    }

}

export default Pastorders;