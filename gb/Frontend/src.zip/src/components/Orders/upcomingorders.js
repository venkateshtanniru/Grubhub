import React, { Component } from "react";
// import {Link} from "react-router-dom";

class Upcomingorders extends Component{
    render(){
        return(
            <div className="container-fluid">
                 
                 <h2>Upcoming Orders!</h2>

            </div>
        )
    }

}

export default Upcomingorders;